<div class="panel panel-primary portlet">
  <div class="panel-heading portlet-header">Messages</div>
  <div class="panel-body">
    <center>You have no new messages.</center>
  </div>
</div>
