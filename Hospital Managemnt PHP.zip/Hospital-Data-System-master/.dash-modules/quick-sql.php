<div class="panel panel-info portlet">
  <div class="panel-heading portlet-header">Quick Sql</div>
  <div class="panel-body">
  <form action="../pdf/generator.php" method="post">
    <textarea class="form-control" name="query" rows="3"></textarea><br/>
	<input type="submit" value="submit"/>
  </form>
  </div>
  
</div> 
