<div class="panel panel-primary portlet">
  <div class="panel-heading portlet-header">News</div>
  <div class="panel-body">
    <center>Nothing has been posted in the last 7 days.</center>
  </div>
</div>