
<!DOCTYPE HTML>
<html lang="en">
	<head>
		<base href="http://localhost/">
		<title>INB201</title>
		<!--JavaScript -->
		<script src="js/jquery-2.1.0.min.js" type="text/javascript"></script>
		<script src="js/bootstrap.js" type="text/javascript"></script>
        <script src="//code.jquery.com/jquery-1.9.1.js"></script>
		<script src="//code.jquery.com/ui/1.10.4/jquery-ui.js"></script>
		<script src="js/holder.js"></script>
		
		<!--CSS -->
		<link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
		<link rel="stylesheet" href="css/bootstrap-theme.min.css" type="text/css">
		<link rel="stylesheet" href="//code.jquery.com/ui/1.10.4/themes/smoothness/jquery-ui.css">
		<link rel="stylesheet" href="css/additional-styles.css" type="text/css">
		<!-- Meta -->
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
	</head>
	<body>
	<p>Wieiieie</p><div class="container"></div>
	</body>
 </html>