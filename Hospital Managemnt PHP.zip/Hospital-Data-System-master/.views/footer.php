		<nav class="navbar navbar-default navbar-fixed-bottom" role="navigation">
		  <div class="container-fluid">
			  <div class="pull-left">&copy; Team 1 Workshop 7 2014</div>
			  <div class="pull-right">
				<ul class="footer-buttons">
					<li class="footer-buttons-title">
						Useful Links
					</li>
					<li class="footer-buttons-item">
						<a href="/index.php">Home</a>
					</li>
					<li class="footer-buttons-item">
						<a href="#">Sitemap</a>
					</li>
				</ul>
				<ul class="footer-buttons">
					<li class="footer-buttons-title">
						Staff
					</li>
					<li class="footer-buttons-item">
						<a href="/profile.php">Profile</a>
					</li>
					<li class="footer-buttons-item">
						<a href="/assign-staff.php">Assign Staff</a>
					</li>
				</ul>
				<ul class="footer-buttons">
					<li class="footer-buttons-title">
						Patients
					</li>
					<li class="footer-buttons-item">
						<a href="/patient/new-patient.php">New Patient</a>
					</li>
					<li class="footer-buttons-item">
						<a href="/patient/patient-list.php">Patient List</a>
					</li>
				</ul>
				<ul class="footer-buttons">
					<li class="footer-buttons-title">
						Resources
					</li>
					<li class="footer-buttons-item">
						<a href="/resources/index.php">Resource List</a>
					</li>
					<li class="footer-buttons-item">
						<a href="/resources/create.php">Create Resource</a>
					</li>
				</ul>
			  </div>
		  </div>
		</nav>
	</body>
</html>
